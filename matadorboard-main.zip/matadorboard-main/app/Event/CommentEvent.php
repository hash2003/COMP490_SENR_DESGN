<?php

namespace Kanboard\Event;

class CommentEvent extends GenericEvent
{
}
