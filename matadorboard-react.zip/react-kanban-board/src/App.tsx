import React from "react";
import Navbar from "./components/Navbar";
import KanbanBoard from "./components/KanbanBoard";

const App: React.FC = () => {
  return (
    <div
      className="min-h-screen bg-cover bg-center bg-no-repeat"
      style={{ backgroundImage: "url('/MatadorBoard.jpg')" }}
    >
      {/* Overlay to enhance text readability */}
      <div className="bg-black bg-opacity-60 min-h-screen">
        {/* Add Navbar */}
        <Navbar />

        {/* Main Content */}
        <div className="container mx-auto mt-6 px-4 text-center">
          <h1 className="text-5xl font-bold text-red-600 drop-shadow-lg">
            Welcome to Matador Board
          </h1>
          <p className="text-gray-200 mt-2 text-lg drop-shadow-md">
            A streamlined document approval and workflow system for CSUN
            students and faculty.
          </p>

          {/* Render Kanban Board with background styling */}
          <div className="mt-6 bg-white bg-opacity-90 p-4 rounded-lg shadow-lg">
            <KanbanBoard />
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
