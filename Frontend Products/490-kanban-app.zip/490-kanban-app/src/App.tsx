import React from 'react';
import KanbanBoard from './Message';

function App() {
  return (
    <div>
      <KanbanBoard />
    </div>
  );
}

export default App;
