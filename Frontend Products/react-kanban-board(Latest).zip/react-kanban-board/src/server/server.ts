import express from 'express';
import axios from 'axios';
import cors from 'cors';
import bodyParser from 'body-parser';
import pool from './db';

const app = express();
const port = 5000;

app.use(cors()); 
app.use(bodyParser.json());

const users: { [key: string]: any } = {};  


app.post('/api/login', async (req, res) => {
  const { tokenId } = req.body;
  console.log(tokenId)

  try {
    const response = await axios.get(
      `https://oauth2.googleapis.com/tokeninfo?id_token=${tokenId}`,
      {
        headers: {
          'Content-Type': 'application/json', 
        },
      }
    );

    const email = response.data.email;
    console.log(email)

    interface User {
      email: string;
      name: string;
    }

    const [results] = await pool.promise().query('SELECT * FROM users WHERE email = ?', [email]);
    const userRows = results as User[];

    if (userRows.length > 0) {
      console.log('User found:', userRows[0]);
      res.json({ user: userRows[0] });
    } else {
      const [newUserRows] = await pool.promise().query(
        'INSERT INTO users (email, name) VALUES (?, ?)',
        [email, response.data.name]
      );

      const newUser = {
        email,
        name: response.data.name,
        id: (newUserRows as any).insertId,
      }

      res.json({ user: newUser });
    }
  } catch (error) {
    console.error('Error verifying token:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.get('/api/boards', async (req, res) => {
  const { userId } = req.query;  
  
  try {
    const [boards] = await pool.promise().query(
      'SELECT * FROM boards WHERE user_id = ?',
      [userId]
    );

    res.json({ boards });
  } catch (error) {
    console.error('Error fetching boards:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.post('/api/boards', async (req, res) => {
  const { userId, name } = req.body;  

  try {
    const [result] = await pool.promise().query(
      'INSERT INTO boards (user_id, name) VALUES (?, ?)',
      [userId, name]
    );

    const newBoard = {
      id: (result as any).insertId,
      userId,
      name,
    };

    res.json({ board: newBoard });
  } catch (error) {
    console.error('Error creating board:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.get('/api/columns/:boardId', async (req, res) => {
  const { boardId } = req.params;

  try {
    const [columns] = await pool.promise().query(
      'SELECT * FROM columns WHERE board_id = ? ORDER BY position',
      [boardId]
    );

    res.json({ columns });
  } catch (error) {
    console.error('Error fetching columns:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.post('/api/columns', async (req, res) => {
  const { boardId, name, position } = req.body;  

  try {
    const [result] = await pool.promise().query(
      'INSERT INTO columns (board_id, name, position) VALUES (?, ?, ?)',
      [boardId, name, position]
    );

    const newColumn = {
      id: (result as any).insertId,
      boardId,
      name,
      position,
    };

    res.json({ column: newColumn });
  } catch (error) {
    console.error('Error creating column:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.get('/api/tasks/:columnId', async (req, res) => {
  const { columnId } = req.params;

  try {
    const [tasks] = await pool.promise().query(
      'SELECT * FROM tasks WHERE column_id = ? ORDER BY position',
      [columnId]
    );

    res.json({ tasks });
  } catch (error) {
    console.error('Error fetching tasks:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.post('/api/tasks', async (req, res) => {
  const { columnId, title, description, position } = req.body;  

  try {
    const [result] = await pool.promise().query(
      'INSERT INTO tasks (column_id, title, description, position) VALUES (?, ?, ?, ?)',
      [columnId, title, description, position]
    );

    const newTask = {
      id: (result as any).insertId,
      columnId,
      title,
      description,
      position,
    };

    res.json({ task: newTask });
  } catch (error) {
    console.error('Error creating task:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
