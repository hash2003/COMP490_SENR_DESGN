import React from "react";

const Navbar: React.FC = () => {
  return (
    <nav className="bg-white border-b-4 border-red-700 px-6 py-4 shadow-md flex justify-between items-center">
      {/* Left: Logo */}
      <div className="flex items-center space-x-4">
        <img
          src="/MatadorBoard.jpg"
          alt="Matador Board Logo"
          className="h-[80px] w-auto"
        />
      </div>

      {/* Center: Navigation Links */}
      <div className="hidden md:flex space-x-7">
        <a href="#" className="rounded-md bg-gray-400 px-4 py-2 text-gray-800 hover:text-red-700">
          Home
        </a>
        <a href="#" className="rounded-md bg-gray-400 px-4 py-2 text-gray-800 hover:text-red-700">
          Group Management
        </a>
        <a href="#" className="rounded-md bg-gray-400 px-4 py-2 text-gray-800 hover:text-red-700">
          Documents
        </a>
        <a href="#" className="rounded-md bg-gray-400 px-4 py-2 text-gray-800 hover:text-red-700">
          Profile
        </a>
      </div>

      {/* Right: Login Button */}
      <div>
        <button className="bg-red-700 text-white px-4 py-2 rounded-md hover:bg-red-800">
          Login
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
