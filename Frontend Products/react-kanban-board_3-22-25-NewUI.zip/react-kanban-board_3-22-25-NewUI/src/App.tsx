import React, { useState, useEffect } from "react";
import { GoogleOAuthProvider, GoogleLogin } from "@react-oauth/google";
import Navbar from "./components/Navbar";
import KanbanBoard from "./components/KanbanBoard";
import axios from "axios";
import { useDispatch } from "react-redux";
import { kanbanActions } from "./store/kanbanSlice";

const App: React.FC = () => {
  const dispatch = useDispatch();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userEmail, setUserEmail] = useState<string | null>(null);

  useEffect(() => {
    const token = localStorage.getItem("authToken");
    const email = localStorage.getItem("userEmail");
    if (token) {
      setIsLoggedIn(true);
      if (email) setUserEmail(email);
    }
  }, []);

  const handleLoginSuccess = async (response: any) => {
    const { credential } = response;
    if (credential) {
      try {
        localStorage.setItem("authToken", credential); // Save token
        const res = await axios.post("http://localhost:5000/api/login", {
          tokenId: credential,
        });
        const userData = res.data.user;
        localStorage.setItem("userEmail", userData.email); // Save email
        setUserEmail(userData.email);
        dispatch(kanbanActions.setBoard({ columns: userData.tasks ?? [] }));
        setIsLoggedIn(true);
      } catch (error) {
        console.error("Login failed:", error);
      }
    } else {
      console.error("Google login response does not contain 'credential'.");
    }
  };

  const handleLoginFailure = () => {
    console.error("Login Error");
  };

  const handleLogout = () => {
    localStorage.removeItem("authToken");
    localStorage.removeItem("userEmail");
    setUserEmail(null);
    dispatch(kanbanActions.setBoard({ columns: [] })); // Reset board state
    setIsLoggedIn(false);
  };

  return (
    <div className="app-container relative">
      {/* Dark Overlay */}
      <div className="absolute inset-0 bg-black bg-opacity-30 z-0"></div>
  
      <div className="relative z-10">
        <div className="navbar-container">
          <img src="/public/logo.png" alt="Logo" className="navbar-logo" />
          <div className="navbar-links">
            <a href="#home">Home</a>
            <a href="#group-management">Group Management</a>
            <a href="#documents">Documents</a>
            <a href="#profile">Profile</a>
          </div>
        </div>
  
        <div className="welcome-section">
          <h1 className="welcome-title text-white">
            Welcome to <span className="highlight">Matador Board</span>
          </h1>
          <p className="welcome-subtitle text-gray-200">
            An efficient system for document approval and workflow designed for CSUN staff and faculty.
          </p>
        </div>
  
        {isLoggedIn && (
          <div className="user-info text-white">
            <p className="logged-in-text text-white">
              Logged in as: <span className="user-email">{userEmail}</span>
            </p>
            <button className="logout-button bg-gray-800 text-white p-2 rounded">
              Logout
            </button>
          </div>
        )}
  
        {!isLoggedIn ? (
          <GoogleOAuthProvider clientId="your-google-client-id">
            <GoogleLogin
              onSuccess={handleLoginSuccess}
              onError={handleLoginFailure}
            />
          </GoogleOAuthProvider>
        ) : (
          <KanbanBoard />
        )}
      </div>
    </div>
  );
  
};

export default App;