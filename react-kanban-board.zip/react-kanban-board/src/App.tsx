import React, { useState, useEffect } from "react";
import { GoogleOAuthProvider, GoogleLogin } from "@react-oauth/google";
import Navbar from "./components/Navbar";
import KanbanBoard from "./components/KanbanBoard";
import axios from "axios";
import { useDispatch } from "react-redux";
import { kanbanActions } from "./store/kanbanSlice";

const App: React.FC = () => {
  const dispatch = useDispatch();
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
  const [userEmail, setUserEmail] = useState<string | null>(null);

  useEffect(() => {
    const token = localStorage.getItem("authToken");
    const email = localStorage.getItem("userEmail");
    if (token) {
      setIsLoggedIn(true);
      if (email) setUserEmail(email);
    }
  }, []);

  const handleLoginSuccess = async (response: any) => {
    const { credential } = response;
    console.log("----------this is the response: ", response);
    console.log("----------this is the cred: ", credential);

    if (credential) {
      try {
        localStorage.setItem("authToken", credential); // Save token
        
        const res = await axios.post("http://localhost:5000/api/login", {
          tokenId: credential,
        });

        const userData = res.data.user;
        localStorage.setItem("userEmail", userData.email); // Save email
        setUserEmail(userData.email);
        
        dispatch(kanbanActions.setBoard({ columns: userData.tasks ?? [] }));
        setIsLoggedIn(true);
      } catch (error) {
        console.error("Login failed:", error);
      }
    } else {
      console.error("Google login response does not contain 'credential'.");
    }
  };

  const handleLoginFailure = () => {
    console.error("Login Error");
  };

  const handleLogout = () => {
    localStorage.removeItem("authToken");
    localStorage.removeItem("userEmail");
    setUserEmail(null);
    dispatch(kanbanActions.setBoard({ columns: [] })); // Reset board state
    setIsLoggedIn(false);
  };

  return (
    <GoogleOAuthProvider clientId="1069732843909-eq4iupt4u7rqaan4qfuebkfghi8nrsqd.apps.googleusercontent.com">
      <div>
        <div className="bg-zinc-900 min-h-screen">
          <Navbar />
          <div className="container mx-auto m-[125px] px-4">
            <h1 className="text-4xl font-bold text-white-800">
              Welcome to <span className="text-red-500">Matador Board.</span>
            </h1>
            <p className="text-white-500 mt-2 text-sm">
              A streamlined document approval and workflow system for CSUN staff and faculty.
            </p>
            {!isLoggedIn ? (
              <div className="mt-6">
                <GoogleLogin onSuccess={handleLoginSuccess} onError={handleLoginFailure} useOneTap />
              </div>
            ) : (
              <div className="mt-6 text-green-500">
                <p>Logged in as: {userEmail}</p>
                <button onClick={handleLogout} className="text-red-500 underline mt-2">
                  Logout
                </button>
              </div>
            )}
            <div className="mt-6 bg-white-900 rounded-lg">
              {isLoggedIn && <KanbanBoard />}
            </div>
          </div>
        </div>
      </div>
    </GoogleOAuthProvider>
  );
};

export default App;