import {
  SortableContext,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { useMemo, useState } from 'react';
import { FaPlusCircle } from 'react-icons/fa';
import { RiDeleteBinLine } from 'react-icons/ri';
import useEditable from '../hooks/useEditable';
import { Column, kanbanActions } from '../store/kanbanSlice';
import { useAppDispatch, useAppSelector } from '../util/reduxHooks';
import KanbanTaskItem from './KanbanTaskItem';

type Props = {
  column: Column;
};

function KanbanColumn({ column }: Props) {
  const dispatch = useAppDispatch();
  const [color, setColor] = useState(column.color || "#1E293B");
  const isLastColumn = useAppSelector((state) => state.kanban.columns.length === 1);

  const handleColorChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newColor = event.target.value;
    setColor(newColor);
    dispatch(kanbanActions.changeColumnColor({ columnId: column.id, color: newColor }));
  };

  const { handleBlur, handleKeyDown, isEditable, setIsEditable } = useEditable();
  const { tasks, id, title } = column;
  const taskIds = useMemo(() => tasks.map((task) => task.id), [tasks]);

  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({
    id,
    data: { type: 'column', column },
  });

  const style = {
    transition,
    transform: CSS.Translate.toString(transform),
  };

  const deleteColumnHandler = () => {
    dispatch(kanbanActions.deleteColumn(column.id));
  };

  const createTaskHandler = () => {
    dispatch(kanbanActions.addTaskToColumnById(column.id));
  };

  const handleInputChange = (event: React.FormEvent<HTMLInputElement>) => {
    const newTitle = event.currentTarget.value;
    dispatch(kanbanActions.renameColumn({ columnId: id, newTitle }));
  };

  return (
    <div
      className={`z-10 w-72 min-w-72 cursor-grab active:cursor-grabbing rounded-lg flex flex-col ${isDragging ? 'opacity-50 z-0' : ''}`}
      ref={setNodeRef}
      style={style}
      {...listeners}
      {...attributes}
    >
      {/* Column Header (Title Bar) */}
      <div 
        onClick={() => setIsEditable(true)} 
        onBlur={handleBlur} 
        className="px-4 py-3 text-sm flex bg-red-500 items-center justify-between min-h-10 rounded-t-lg"
      >
        <div className="cursor-text flex items-center gap-2 w-full">
          {isEditable ? (
            <input
              onChange={handleInputChange}
              type="text"
              className="font-bold text-md w-full h-[1.2rem] bg-transparent outline-none text-white"
              defaultValue={title}
              autoFocus
              onKeyDown={handleKeyDown}
            />
          ) : (
            <span className="font-bold text-md text-white text-wrap break-words">{title}</span>
          )}
        </div>

        {!isLastColumn && (
          <button className="text-lg text-white-500 hover:text-red-500 transition" onClick={deleteColumnHandler}>
            <RiDeleteBinLine />
          </button>
        )}
      </div>

      {/* Task List & Add Button inside */}
      <SortableContext items={taskIds} strategy={verticalListSortingStrategy}>
        <div className="p-3 flex flex-col gap-3 bg-zinc-950/25 rounded-b-lg">
          {tasks.map((task) => (
            <KanbanTaskItem key={task.id} task={task} parentId={column.id} />
          ))}
          
          {/* Add Task Button Inside the Column */}
          <button
            onClick={createTaskHandler}
            className="flex items-center gap-2 py-2 px-3 mt-2 rounded-md border border-transparent hover:border-red-500 text-white rounded transition"
          >
            <FaPlusCircle />
            <span className="text-xs">Add New Task</span>
          </button>
        </div>
      </SortableContext>
    </div>
  );
}

export default KanbanColumn;
